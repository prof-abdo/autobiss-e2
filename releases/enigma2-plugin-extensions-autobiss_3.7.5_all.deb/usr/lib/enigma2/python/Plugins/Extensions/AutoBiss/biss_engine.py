# -*- coding: utf-8 -*-
"""
AutoBiss E2 - BISS Engine Module v3.5
Real-time CW extraction from tsdec stderr, SoftCam.Key writer, softcam reloader
Compatible with Python 2.7 and Python 3.x
"""
from __future__ import absolute_import, print_function, division

import os
import re
import json
import base64
import threading
import subprocess
import time as _timemod
from time import strftime, time
try:
    from time import sleep as _sleep
except Exception:
    _sleep = None


def _proc_wait(proc, timeout):
    """proc.wait(timeout) that also works on Python 2 (no timeout kwarg)."""
    try:
        return proc.wait(timeout=timeout)
    except TypeError:
        end = _timemod.time() + max(1, timeout)
        while _timemod.time() < end:
            if proc.poll() is not None:
                return proc.returncode
            if _sleep:
                _sleep(0.05)
        try:
            proc.kill()
        except Exception:
            pass
        return proc.wait()


def _proc_communicate(proc, timeout=None):
    """proc.communicate(timeout) with a Python 2 fallback."""
    if timeout is None:
        return proc.communicate()
    try:
        return proc.communicate(timeout=timeout)
    except TypeError:
        return proc.communicate()

# ------------------------------------------------------------------------------
# Debug helper
# ------------------------------------------------------------------------------
_DEBUG_PATH = '/tmp/autobiss_debug.log'

def log_debug(msg):
    try:
        with open(_DEBUG_PATH, 'a') as f:
            f.write("[{}] [biss_engine] {}\n".format(strftime("%Y-%m-%d %H:%M:%S"), msg))
        try:
            os.chmod(_DEBUG_PATH, 0o600)
        except Exception:
            pass
    except Exception:
        pass

def _mask_cw(cw):
    """Return a partially masked CW for safe logging (first 4 hex chars visible)."""
    if not cw or len(cw) < 4:
        return "****"
    return "{}{}".format(cw[:4], "*" * (len(cw) - 4))

# ------------------------------------------------------------------------------
# Constants
# ------------------------------------------------------------------------------
BISS_CAID = 0x2600
KEYS_FILE = "/media/hdd/biss_keys.txt"
SOFTCAM_KEY = "/etc/tuxbox/config/SoftCam.Key"
OUTPUT_DIR = "/media/hdd/movie/"
TSDEC_CMD = "tsdec"
OSCAM_WEB_PORT = 8888

# ------------------------------------------------------------------------------
# Settings (persisted in /etc/enigma2 so updates never wipe them)
# ------------------------------------------------------------------------------
SETTINGS_FILE = "/etc/enigma2/autobiss_settings.json"
SOFTCAM_CANDIDATES = [
    "/etc/tuxbox/config/SoftCam.Key",
    "/etc/tuxbox/config/ncam/SoftCam.Key",
    "/etc/tuxbox/config/oscam-emu/SoftCam.Key",
    "/etc/tuxbox/config/oscam/SoftCam.Key",
    "/etc/tuxbox/config/oscam/oscam.keys",
    "/usr/keys/SoftCam.Key",
    "/var/keys/SoftCam.Key",
    "/etc/SoftCam.Key",
]

# Directories where older AutoBiss versions could have stored the private
# CW_list.cwl.  The list must never remain on a client receiver.
PRIVATE_CWL_DIRS = [
    "/tmp",
    "/media/hdd",
    "/media/hdd/movie",
    "/media/usb",
    "/media/usb/movie",
    "/media/ssd",
    "/media/ssd/movie",
    "/data",
    "/etc",
    "/etc/enigma2",
    "/usr/keys",
    "/var/keys",
    "/usr/lib/enigma2/python/Plugins/Extensions/AutoBiss",
]


def cleanup_private_cwl_files():
    """Delete private CW_list*.cwl copies left by older plugin versions.

    Never raises; returns the list of removed paths.  This runs at plugin
    startup and again from the updater, so clients that update from an old
    version lose any private key list they still have on disk.
    """
    removed = []
    for directory in PRIVATE_CWL_DIRS:
        try:
            names = os.listdir(directory)
        except Exception:
            continue
        for name in names:
            low = name.lower()
            if not low.startswith("cw_list"):
                continue
            if not (low.endswith(".cwl") or low.endswith(".cwl.tmp")):
                continue
            path = os.path.join(directory, name)
            try:
                if os.path.isfile(path):
                    os.remove(path)
                    removed.append(path)
                    log_debug("Removed private CWL copy: {}".format(path))
            except Exception as e:
                log_debug("Could not remove private CWL {}: {}".format(path, e))
    return removed

def _infer_emu_config_dir(name):
    """Find the config dir of a daemon started without --config-dir (DreamOS)."""
    candidates = [
        '/etc/tuxbox/config',
        '/etc/tuxbox/config/oscam-emu',
        '/etc/tuxbox/config/oscam',
        '/etc/tuxbox/config/ncam',
        '/var/tuxbox/config',
        '/var/etc/oscam',
        '/etc/oscam',
        '/usr/local/etc/oscam',
    ]
    found = set()
    for directory in candidates:
        try:
            if not os.path.isfile(os.path.join(directory, name + '.server')):
                continue
            sections = _read_cam_sections(os.path.join(directory, name + '.server'))
        except Exception:
            continue
        emu = [s for s in sections if s.get('section') == 'reader'
               and s.get('protocol', '').lower() == 'emu'
               and s.get('enable', '1') != '0']
        if len(emu) != 1:
            continue
        device = (emu[0].get('device') or '').strip()
        if device.startswith('/') and not os.path.isdir(device):
            directory = os.path.dirname(device) or directory
        if os.path.isfile(os.path.join(directory, name + '.conf')):
            found.add(directory)
    return found.pop() if len(found) == 1 else None


def _detect_emu_instance(proc_dir='/proc'):
    """Select one executable-validated emulator and its supervisor/worker tree."""
    try:
        processes = []
        for pid in os.listdir(proc_dir):
            if not pid.isdigit():
                continue
            try:
                root = os.path.join(proc_dir, pid)
                exe = os.readlink(os.path.join(root, 'exe'))
            except Exception:
                continue
            base = os.path.basename(exe).lower()
            if not base.startswith(('oscam', 'ncam')):
                continue
            with open(os.path.join(root, 'cmdline'), 'rb') as f:
                parts = [p.decode('utf-8', 'replace') for p in f.read().split(b'\x00') if p]
            directory = None
            for i, arg in enumerate(parts):
                if arg in ('--config-dir', '-c') and i + 1 < len(parts):
                    directory = parts[i + 1]
                elif arg.startswith('--config-dir='):
                    directory = arg.split('=', 1)[1]
            if not directory or not directory.startswith('/'):
                directory = _infer_emu_config_dir('ncam' if base.startswith('ncam') else 'oscam')
            if not directory: 
                return None
            with open(os.path.join(root, 'status'), 'r') as f:
                match = re.search(r'^PPid:\s*(\d+)', f.read(), re.MULTILINE)
            if not match:
                return None
            processes.append((int(pid), int(match.group(1)), exe, directory,
                              'ncam' if base.startswith('ncam') else 'oscam'))
        identities = set((p[2], p[3], p[4]) for p in processes)
        if len(identities) != 1:
            return None
        # DreamOS reparents the worker, so a strict one-root check rejects a
        # perfectly valid OSCam master/worker pair.  One unique executable +
        # config identity is enough; different instances are still rejected.
        _, directory, name = identities.pop()
        return {'name': name, 'config_dir': directory}
    except Exception:
        # An emulator exited or could not be inspected. Do not guess another.
        return None


def _detect_emu_config_dir():
    """Return the config directory only when a unique active instance exists."""
    instance = _detect_emu_instance()
    if instance:
        return instance['config_dir']
    return None
DEFAULT_SETTINGS = {
    "softcam_path":   "auto",
    "record_duration": 1,
    "cooldown":        60,
    "notifications":   True,
    "last_feed_cursor": "",
}

def load_settings():
    """Load settings dict, merged over DEFAULT_SETTINGS. Never raises."""
    cfg = dict(DEFAULT_SETTINGS)
    try:
        if os.path.isfile(SETTINGS_FILE):
            with open(SETTINGS_FILE, "r") as f:
                data = json.load(f)
            if isinstance(data, dict):
                for k, v in data.items():
                    if k in cfg:
                        cfg[k] = v
    except Exception as e:
        log_debug("load_settings error: {}".format(e))
    try:
        cfg["record_duration"] = int(cfg.get("record_duration", 1))
    except Exception:
        cfg["record_duration"] = 1
    if cfg["record_duration"] not in (1, 2, 3, 5):
        cfg["record_duration"] = 1
    try:
        cfg["cooldown"] = int(cfg.get("cooldown", 60))
    except Exception:
        cfg["cooldown"] = 60
    if cfg["cooldown"] not in (30, 60, 120, 300):
        cfg["cooldown"] = 60
    cfg["notifications"] = bool(cfg.get("notifications", True))
    cfg["last_feed_cursor"] = str(cfg.get("last_feed_cursor", "") or "")
    if cfg.get("softcam_path") not in (["auto"] + SOFTCAM_CANDIDATES):
        cfg["softcam_path"] = "auto"
    return cfg

def save_settings(cfg):
    """Persist settings dict. Returns True on success."""
    try:
        clean = {}
        for k in DEFAULT_SETTINGS:
            clean[k] = cfg.get(k, DEFAULT_SETTINGS[k])
        with open(SETTINGS_FILE, "w") as f:
            json.dump(clean, f)
        try:
            os.chmod(SETTINGS_FILE, 0o600)
        except Exception:
            pass
        log_debug("Settings saved: {}".format(clean))
        return True
    except Exception as e:
        log_debug("save_settings error: {}".format(e))
        return False

def _emu_reader_section(instance):
    """Return the active emulator reader section from the instance config."""
    try:
        path = os.path.join(instance['config_dir'], instance['name'] + '.server')
        for section in _read_cam_sections(path):
            if (section.get('section') == 'reader'
                    and section.get('protocol', '').lower() == 'emu'
                    and section.get('enable', '1') != '0'
                    and section.get('label')):
                return section
    except Exception:
        pass
    return None


def get_softcam_path(cfg=None):
    """Resolve SoftCam.Key path.

    Priority: explicit setting > active emulator's reader device >
    active config dir > first existing candidate > default.
    """
    try:
        path = (cfg or load_settings()).get("softcam_path", "auto")
        if path and path != "auto" and os.path.isfile(path):
            return path
    except Exception:
        pass
    try:
        instance = _detect_emu_instance()
        if instance:
            reader = _emu_reader_section(instance)
            device = (reader or {}).get('device', '').strip()
            if (device.startswith('/') and not device.lower().startswith('http')
                    and not os.path.isdir(device)):
                log_debug("Active emulator key file: {}".format(device))
                return device
            emu_dir = instance['config_dir']
            # The running emulator may keep its keys in a sub-directory
            # (e.g. /etc/tuxbox/config/ncam/SoftCam.Key).  Only use a path
            # that exists, otherwise use the standard path in the active
            # emulator's directory (the writer creates the file).
            for emu_key in (os.path.join(emu_dir, "SoftCam.Key"),
                            os.path.join(emu_dir, "ncam", "SoftCam.Key"),
                            os.path.join(emu_dir, "oscam", "SoftCam.Key")):
                if os.path.isfile(emu_key):
                    log_debug("Emulator config dir detected: {}".format(emu_key))
                    return emu_key
            default_key = os.path.join(emu_dir, "SoftCam.Key")
            log_debug("Emulator dir {} has no SoftCam.Key, will use {}".format(
                emu_dir, default_key))
            return default_key
    except Exception as e:
        log_debug("Emu config dir detect error: {}".format(e))
    for cand in SOFTCAM_CANDIDATES:
        try:
            if os.path.isfile(cand):
                return cand
        except Exception:
            pass
    return SOFTCAM_KEY

def remove_autobiss_keys():
    """Delete AutoBiss-written lines from every known SoftCam.Key file."""
    removed = 0
    targets = []
    try:
        targets.append(get_softcam_path())
    except Exception:
        pass
    for cand in SOFTCAM_CANDIDATES:
        if cand not in targets:
            targets.append(cand)
    for path in targets:
        try:
            if not os.path.isfile(path):
                continue
            with open(path, "r") as f:
                lines = f.readlines()
            kept = [l for l in lines if "[AutoBiss]" not in l]
            lost = len(lines) - len(kept)
            if lost > 0:
                with open(path, "w") as f:
                    f.writelines(kept)
                removed += lost
                log_debug("Cleanup: removed {} lines from {}".format(lost, path))
        except Exception as e:
            log_debug("Cleanup error on {}: {}".format(path, e))
    return removed

# ------------------------------------------------------------------------------
# CW Cache
# ------------------------------------------------------------------------------
class CWCache(object):
    """
    In-memory cache of SID -> CW mappings, persisted to biss_keys.txt.

    Format per line (single source of truth for file + UI):
        F <SID> <VPID> <CW_HEX> <CHANNEL_NAME>
    """
    def __init__(self, path=None):
        self._cache = {}   # sid_int -> cw_hex_str
        self._meta = {}    # sid_int -> (vpid, name)
        # SID alone is not unique: the same program number exists on many
        # transponders.  Correct lookups use the full service reference.
        self._refs = {}    # (service_ref, sid) -> cw_hex_str
        if path is False:
            self._path = None
        else:
            self._path = path or self._default_path()
        self._refs_path = (self._path + ".refs") if self._path else None
        if self._path:
            self._load()
            self._load_refs()

    @staticmethod
    def _default_path():
        for base in ("/media/hdd", "/media/usb", "/media/ssd", "/data"):
            try:
                if os.path.isdir(base):
                    return os.path.join(base, "biss_keys.txt")
            except Exception:
                continue
        return KEYS_FILE

    @property
    def path(self):
        return self._path

    def _load(self):
        if not self._path or not os.path.isfile(self._path):
            return
        try:
            with open(self._path, 'r') as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith('#'):
                        continue
                    parsed = self._parse_line(line)
                    if parsed:
                        sid, cw, vpid, name = parsed
                        self._cache[sid] = cw
                        self._meta[sid] = (vpid, name)
            log_debug("Loaded {} cached CWs from {}".format(len(self._cache), self._path))
        except Exception as e:
            log_debug("Failed to load keys file: {}".format(e))

    def _load_refs(self):
        if not self._refs_path or not os.path.isfile(self._refs_path):
            return
        try:
            with open(self._refs_path, 'r') as f:
                for line in f:
                    parts = line.rstrip("\n").split("\t")
                    if len(parts) != 3 or not _is_cw(parts[2]):
                        continue
                    try:
                        self._refs[(parts[0], int(parts[1]))] = parts[2].upper()
                    except ValueError:
                        continue
            log_debug("Loaded {} service-bound CWs".format(len(self._refs)))
        except Exception as e:
            log_debug("Failed to load refs: {}".format(e))

    def _flush_refs(self):
        if not self._refs_path:
            return True
        try:
            tmp = self._refs_path + ".tmp"
            with open(tmp, 'w') as f:
                for (ref, sid), cw in sorted(self._refs.items()):
                    f.write("{}\t{}\t{}\n".format(ref, sid, cw))
            if hasattr(os, "replace"):
                os.replace(tmp, self._refs_path)
            else:
                try:
                    os.remove(self._refs_path)
                except OSError:
                    pass
                os.rename(tmp, self._refs_path)
            return True
        except Exception as e:
            log_debug("Failed to save refs: {}".format(e))
            return False

    @staticmethod
    def _parse_line(line):
        """Accept the new 'F ...' format and the legacy '=' format."""
        try:
            if line.startswith('F '):
                parts = line.split()
                if len(parts) >= 4:
                    ident = parts[1]
                    # F <IDENT> 00 <CW> ;<name>
                    cw = None
                    if _is_cw(parts[2]):
                        cw = parts[2]
                    elif _is_cw(parts[3]):
                        cw = parts[3]
                    if cw:
                        sid = int(ident[:4], 16)
                        vpid = ident[4:8] if len(ident) >= 8 else ''
                        name = line.split(';', 1)[1] if ';' in line else ''
                        return sid, cw.upper(), vpid, name.replace('[AutoBiss]', '').strip()
                return None
            parts = line.split('=')
            if len(parts) >= 5:
                sid = int(parts[0], 16)
                cw = parts[4].strip().upper()
                if _is_cw(cw):
                    return sid, cw, '', (parts[5].strip() if len(parts) > 5 else '')
        except Exception:
            return None
        return None

    def get(self, sid, service_ref=None):
        # With a service reference only the bound key is valid: falling back
        # to the SID entry would return a CW from another transponder.
        if service_ref:
            return self._refs.get((service_ref, sid))
        return self._cache.get(sid, None)

    def meta(self, sid):
        return self._meta.get(sid, ('', 'AutoBiss'))

    def set(self, sid, cw_hex, vpid='', name='AutoBiss', service_ref=None):
        cw_hex = (cw_hex or '').strip().upper()
        if not _is_cw(cw_hex):
            return False
        self._cache[sid] = cw_hex
        self._meta[sid] = (vpid or '', name or 'AutoBiss')
        if service_ref:
            self._refs[(service_ref, sid)] = cw_hex
            self._flush_refs()
        return self._flush()

    def remove(self, sid):
        if sid in self._cache:
            del self._cache[sid]
            self._meta.pop(sid, None)
            for key in [k for k in self._refs if k[1] == sid]:
                del self._refs[key]
            self._flush_refs()
            return self._flush()
        return False

    def all(self):
        return [(sid, self._cache[sid], self._meta.get(sid, ('', ''))[0],
                 self._meta.get(sid, ('', ''))[1])
                for sid in sorted(self._cache)]

    def count(self):
        return len(self._cache)

    def reload(self):
        """Re-read the keys file (used by the 24h feed scanner)."""
        self._cache = {}
        self._meta = {}
        if not self._path:
            return 0
        self._path = self._default_path()
        self._load()
        return len(self._cache)

    def _flush(self):
        if not self._path:
            return True
        try:
            directory = os.path.dirname(self._path)
            if directory and not os.path.isdir(directory):
                os.makedirs(directory)
            lines = []
            for sid, cw, vpid, name in self.all():
                ident = '{:04X}{}'.format(sid & 0xFFFF, (vpid or '0000').upper())
                if not name:
                    name = 'AutoBiss'
                lines.append("F {} 00 {} ;{} [AutoBiss]\n".format(ident, cw, name))
            with open(self._path, 'w') as f:
                f.writelines(lines)
            try:
                os.chmod(self._path, 0o644)
            except Exception:
                pass
            return True
        except Exception as e:
            log_debug("Failed to write keys file: {}".format(e))
            return False


def _is_cw(cw):
    return bool(cw) and len(cw) == 16 and all(c in '0123456789ABCDEFabcdef' for c in cw)

# ------------------------------------------------------------------------------
# ecm.info Parser (kept for compatibility, but not primary method)
# ------------------------------------------------------------------------------
def _parse_ecm_content(content):
    """Try to extract 16-char hex CW from ecm file content."""
    cw = None
    content_str = content.decode('utf-8', 'replace') if isinstance(content, bytes) else content

    # Pattern 1: cw=1122334455667788
    m = re.search(r'(?:cw|CW)\s*[:=]\s*([0-9A-Fa-f]{16})', content_str, re.IGNORECASE)
    if m:
        cw = m.group(1).upper()
    else:
        # Pattern 2: Two-part CW: cw0=11223344 cw1=55667788
        m0 = re.search(r'(?:cw0|CW0)\s*[:=]\s*([0-9A-Fa-f]{8})', content_str, re.IGNORECASE)
        m1 = re.search(r'(?:cw1|CW1)\s*[:=]\s*([0-9A-Fa-f]{8})', content_str, re.IGNORECASE)
        if m0 and m1:
            cw = (m0.group(1) + m1.group(1)).upper()
        else:
            # Pattern 3: Space-separated bytes
            m = re.search(r'(?<![0-9A-Fa-f])([0-9A-Fa-f]{2}\s+[0-9A-Fa-f]{2}\s+[0-9A-Fa-f]{2}\s+[0-9A-Fa-f]{2}\s+[0-9A-Fa-f]{2}\s+[0-9A-Fa-f]{2}\s+[0-9A-Fa-f]{2}\s+[0-9A-Fa-f]{2})', content_str)
            if m:
                raw = m.group(1).replace(' ', '').upper()
                if len(raw) == 16:
                    cw = raw
    return cw

def parse_ecm_info(sid=None):
    """
    Parse softcam CW files to extract the current BISS key.
    Tries multiple file paths and formats.
    Returns the 16-char hex CW string or None.
    Pass sid to reject keys belonging to a different channel.
    """
    candidates = [
        "/tmp/ecm.info",
        "/tmp/ecm0.info",
        "/tmp/.ecm",
        "/tmp/ecm.info.txt",
        "/tmp/ncam.ecm",
        "/tmp/oscam.ecm",
    ]
    for path in candidates:
        if not os.path.isfile(path):
            continue
        try:
            # A stale ecm.info from the previous channel is the classic source
            # of a wrong CW: only trust files written after the last zap.
            age = time() - os.stat(path).st_mtime
            if age > 8:
                log_debug("Skipping stale ECM file {} (age {:.0f}s)".format(path, age))
                continue
        except Exception:
            pass
        try:
            with open(path, 'rb') as f:
                content = f.read()
            # Older AutoBiss builds wrote this record themselves. It cannot
            # establish that the running softcam accepted a control word.
            if b'using: emu\naddress: local:0\nhops: 0\necm time: 2' in content:
                log_debug("Skipping AutoBiss-generated ECM file {}".format(path))
                continue
            # Match SID when the file exposes it, so a stale ecm.info from a
            # previous channel is never assigned to the current one.
            expected = None
            if isinstance(sid, int):
                expected = '{:04X}'.format(sid)
            found_sid = None
            m = re.search(b'(?im)^\\s*sid\\s*[:=]?\\s*(?:0x)?([0-9a-f]{1,4})\\b', content)
            if m:
                found_sid = m.group(1).decode('ascii', 'replace').upper().zfill(4)
            if expected and found_sid and found_sid != expected:
                log_debug("Skipping {}: SID {} != current {}".format(path, found_sid, expected))
                continue
            cw = _parse_ecm_content(content)
            if cw:
                log_debug("Parsed CW from {}: {}".format(path, _mask_cw(cw)))
                return cw
        except Exception as e:
            log_debug("Failed to read {}: {}".format(path, e))
    log_debug("No CW found in any softcam ECM file")
    return None

# ------------------------------------------------------------------------------
# Global CWL Helper
# ------------------------------------------------------------------------------
GLOBAL_CWL_PATHS = [
    "/media/hdd/movie/CW_list.cwl",
    "/media/hdd/CW_list.cwl",
    "/media/usb/movie/CW_list.cwl",
    "/tmp/CW_list.cwl",
]

def get_global_cwl():
    """
    Return the path to the first existing global CWL file, or None.
    These files can be very large (GBs) and are never parsed by the plugin.
    """
    for path in GLOBAL_CWL_PATHS:
        if os.path.isfile(path):
            log_debug("Global CWL found: {}".format(path))
            return path
    log_debug("No global CWL file found in standard locations")
    return None

# ------------------------------------------------------------------------------
# tsdec Real-Time CW Extractor
# ------------------------------------------------------------------------------
def parse_tsdec_stderr(stderr_lines):
    """
    Parse tsdec stderr output to find the CW that achieved sync.
    Looks for lines like:
      sync at packet 15. using CW #42 "0 1A 2B 3C 81 4D 5E 6F 1A"
    Returns the 16-char hex CW string or None.
    """
    cw = None
    for line in stderr_lines:
        # Look for sync line with CW pattern
        m = re.search(r'sync at packet\s+\d+\.\s+using CW\s+#\d+\s+"\d\s+([0-9A-Fa-f\s]+)"', line)
        if m:
            raw = m.group(1).replace(' ', '').upper()
            if len(raw) == 16:
                cw = raw
                log_debug("tsdec sync CW found: {}".format(_mask_cw(cw)))
                break
    return cw

def run_tsdec_extract_cw(ts_path, cwl_path, timeout=60, binary_path=None):
    """
    Run tsdec on a .ts file with a .cwl file and extract the CW that achieves sync.
    Returns (cw_hex, tsdec_rc) where cw_hex may be None if sync not found.
    Kills tsdec early once sync is found to save CPU.
    If binary_path is provided, uses that tsdec binary instead of TSDEC_CMD.
    """
    out_path = ts_path.replace(".ts", "_tmp_dec.ts")
    tsdec_bin = binary_path if binary_path else TSDEC_CMD
    # Use list form (shell=False) to prevent shell injection via path metacharacters
    cmd = [tsdec_bin, '-f', cwl_path, '-i', ts_path, '-o', out_path]
    log_debug("tsdec extract CW: {} (binary={})".format(len(cmd) - 1, tsdec_bin))

    cw = None
    rc = -1
    try:
        proc = subprocess.Popen(
            cmd,
            shell=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )

        stderr_lines = []
        # Read stderr line by line, but enforce a wall-clock deadline so a
        # silent/hung tsdec cannot block the caller indefinitely.
        deadline = _timemod.time() + timeout
        if hasattr(proc.stderr, 'readline'):
            for line in iter(proc.stderr.readline, b''):
                if not line:
                    break
                line_str = line.decode('utf-8', 'replace') if isinstance(line, bytes) else line
                line_str = line_str.strip()
                stderr_lines.append(line_str)
                log_debug("tsdec stderr: {}".format(line_str))

                # Check for sync
                cw = parse_tsdec_stderr([line_str])
                if cw:
                    log_debug("CW found early, killing tsdec")
                    proc.terminate()
                    try:
                        _proc_wait(proc, 2)
                    except Exception:
                        proc.kill()
                    break

                if _timemod.time() > deadline:
                    log_debug("tsdec exceeded {}s, killing".format(timeout))
                    proc.kill()
                    try:
                        _proc_wait(proc, 2)
                    except Exception:
                        pass
                    rc = -1
                    break
            else:
                # If we didn't break out of the loop, wait for process
                try:
                    rc = _proc_wait(proc, max(1, int(deadline - _timemod.time())))
                except Exception:
                    proc.kill()
                    rc = -1
        else:
            # Fallback: just wait and read all stderr at end
            stdout, stderr = _proc_communicate(proc, timeout)
            rc = proc.returncode
            stderr_str = stderr.decode('utf-8', 'replace') if isinstance(stderr, bytes) else stderr
            stderr_lines = stderr_str.splitlines()
            cw = parse_tsdec_stderr(stderr_lines)

    except Exception as e:
        log_debug("tsdec extract exception: {}".format(e))

    # Clean up temp decrypted file (we don't need it, we only needed the CW)
    try:
        if os.path.exists(out_path):
            os.remove(out_path)
    except Exception:
        pass

    log_debug("tsdec extract result: cw={}, rc={}".format(_mask_cw(cw), rc))
    return cw, rc

# ------------------------------------------------------------------------------
# ECM PID Extractor
# ------------------------------------------------------------------------------
def get_ecm_pid(session):
    """
    Try to get the ECM PID for the current service.
    First tries /tmp/ecm.info, then falls back to common BISS default 0x1FFF.
    Returns hex string (e.g., '1FFF') or '1FFF' as default.
    """
    # Try ecm.info first
    candidates = [
        "/tmp/ecm.info",
        "/tmp/ecm0.info",
        "/tmp/.ecm",
        "/tmp/ncam.ecm",
        "/tmp/oscam.ecm",
    ]
    for path in candidates:
        if not os.path.isfile(path):
            continue
        try:
            with open(path, 'rb') as f:
                content = f.read()
            content_str = content.decode('utf-8', 'replace') if isinstance(content, bytes) else content
            # Look for pid or ECMPID patterns
            m = re.search(r'(?:ecm\s*pid|ECMPID|pid)\s*[:=]?\s*(?:0x)?([0-9A-Fa-f]{1,4})', content_str, re.IGNORECASE)
            if m:
                ecm = m.group(1).upper()
                log_debug("ECM PID from {}: 0x{}".format(path, ecm))
                return ecm
        except Exception as e:
            log_debug("Failed to read {} for ECM PID: {}".format(path, e))
    log_debug("ECM PID not found, defaulting to 1FFF")
    return "1FFF"


def get_pmt_pid(sid=None):
    """Return the active PMT PID for the current BISS ECM from OSCam's log.

    DreamOS reports sPMTPID as -1, so the universal-hash example needs the
    PMT that OSCam prints in its 'trying to descramble' line.
    """
    paths = (OSCAM_LOG_FILE + '-prev', OSCAM_LOG_FILE)
    candidates = []
    fallback = []
    for path in paths:
        try:
            with open(path, 'r') as f:
                lines = f.readlines()[-400:]
        except (IOError, OSError):
            continue
        for line in lines:
            match = re.search(
                r'trying to descramble.*CAID\s+2600\b.*?PMTPID\s+([0-9A-F]{4})',
                line, re.IGNORECASE)
            if match:
                candidates.append(match.group(1).upper())
                continue
            match = re.search(
                r'Example key based on universal hash:.*?pmt:([0-9A-F]{4})\s+sid:([0-9A-F]{4})',
                line, re.IGNORECASE)
            if match:
                if sid is None or int(match.group(2), 16) == int(sid):
                    fallback.append(match.group(1).upper())
    if candidates:
        return candidates[-1]
    if fallback:
        return fallback[-1]
    return None

# ------------------------------------------------------------------------------
# VPS Decryptor
# ------------------------------------------------------------------------------
def decrypt_via_vps(ts_path, cwl_path, sid_hex, ecm_pid_hex,
                    vps_url="https://tsdec.kingcs.xyz/decrypt",
                    timeout=30,
                    service_ref="", video_pid="", audio_pid="", pcr_pid="",
                    pmt_pid="", txt_pid="", tsid="", onid="", caid=""):
    """
    Upload a TS sample and optional CWL to the remote VPS for decryption.
    Uses the per-device token stored in /etc/autobiss/token (no shared key).
    Service info (SID, PIDs, service_ref, etc.) is sent to enable VPS-side caching.
    Returns (cw_hex, reachable) where reachable is False on network failure.
    """
    # Load per-device token; fall back to legacy shared key while not yet registered
    _LEGACY_KEY = "a1b2c3d4e5f678901234567890abcdef1234567890abcdef"
    token       = None
    use_legacy  = False
    try:
        from Plugins.Extensions.AutoBiss.device import get_token
        token = get_token()
    except Exception:
        pass
    if not token:
        use_legacy = True
        log_debug("decrypt_via_vps: no device token yet — using legacy API key")

    try:
        import urllib2
    except ImportError:
        import urllib.request as urllib2

    try:
        if ts_path:
            with open(ts_path, "rb") as f:
                ts_data = f.read()
        else:
            ts_data = b""
    except Exception as e:
        log_debug("decrypt_via_vps: cannot read ts: {}".format(e))
        return None, False

    ts_b64 = base64.b64encode(ts_data) if ts_data else ""
    if isinstance(ts_b64, bytes):
        ts_b64 = ts_b64.decode("ascii")

    cwl_b64 = ""
    if cwl_path and os.path.exists(cwl_path):
        try:
            with open(cwl_path, "rb") as f:
                cwl_data = f.read()
            cwl_b64 = base64.b64encode(cwl_data)
            if isinstance(cwl_b64, bytes):
                cwl_b64 = cwl_b64.decode("ascii")
        except Exception as e:
            log_debug("decrypt_via_vps: cannot read cwl: {}".format(e))

    payload = json.dumps({
        "ts_base64": ts_b64,
        "cwl_base64": cwl_b64,
        "sid": sid_hex,
        "ecm_pid": ecm_pid_hex,
        "service_ref": service_ref,
        "video_pid": video_pid,
        "audio_pid": audio_pid,
        "pcr_pid": pcr_pid,
        "pmt_pid": pmt_pid,
        "txt_pid": txt_pid,
        "tsid": tsid,
        "onid": onid,
        "caid": caid
    })

    data = payload.encode("utf-8") if isinstance(payload, str) else payload
    req = urllib2.Request(vps_url, data=data)
    req.add_header("Content-Type", "application/json")
    if use_legacy:
        req.add_header("X-API-Key", _LEGACY_KEY)
    else:
        req.add_header("X-Device-Token", token)

    ssl_ctx = None
    try:
        import ssl
        try:
            ssl_ctx = ssl.create_default_context()   # verify cert chain
        except Exception:
            ssl_ctx = ssl._create_unverified_context()  # old CA store fallback
    except Exception:
        pass

    try:
        if ssl_ctx is not None:
            try:
                response = urllib2.urlopen(req, context=ssl_ctx, timeout=timeout)
            except TypeError:
                response = urllib2.urlopen(req, timeout=timeout)
        else:
            response = urllib2.urlopen(req, timeout=timeout)
        resp_data = response.read()
        if isinstance(resp_data, bytes):
            resp_data = resp_data.decode("utf-8")
        result = json.loads(resp_data)
        if result.get("success") and result.get("cw_hex"):
            log_debug("decrypt_via_vps: CW found: {}".format(_mask_cw(result["cw_hex"])))
            return result["cw_hex"].upper(), True
        log_debug("decrypt_via_vps: no CW in response: {}".format(result.get("message")))
        return None, True
    except Exception as e:
        log_debug("decrypt_via_vps: unreachable: {}".format(e))
        return None, False

# ------------------------------------------------------------------------------
# SoftCam.Key Writer
# ------------------------------------------------------------------------------
OSCAM_LOG_FILE = "/tmp/oscam.log"


def _unify_orbitals(namespace):
    """Copy OSCam's orbital-position normalization used before hashing."""
    pos = (namespace >> 16) & 0x0FFF
    mapping = {
        29: 30, 31: 30, 49: 48, 50: 48, 215: 216, 285: 282,
        328: 330, 329: 330, 331: 330, 359: 360, 361: 360,
        451: 450, 550: 549, 551: 549, 748: 750, 749: 750,
        848: 850, 852: 850, 914: 915, 934: 935, 936: 935,
        3600 - 911: 3600 - 910, 3600 - 870: 3600 - 871,
        3600 - 872: 3600 - 871, 3600 - 432: 3600 - 431,
        3600 - 430: 3600 - 431, 3600 - 376: 3600 - 375,
        3600 - 374: 3600 - 375, 3600 - 359: 3600 - 360,
        3600 - 81: 3600 - 80, 3600 - 73: 3600 - 70,
        3600 - 72: 3600 - 70, 3600 - 71: 3600 - 70,
        3600 - 10: 3600 - 8, 3600 - 9: 3600 - 8,
        3600 - 7: 3600 - 8, 3600 - 6: 3600 - 8,
    }
    pos = mapping.get(pos, pos)
    return (namespace & 0xF000FFFF) | (pos << 16)


def _is_valid_namespace(namespace):
    """OSCam's namespace validation (Ku/C band and orbital sanity)."""
    if (namespace & 0xF0000000) != 0xA0000000:
        return False
    if (namespace & 0x0FFFFFFF) == 0:
        return False
    orbital = (namespace >> 16) & 0x0FFF
    frequency = namespace & 0x7FFF
    if orbital > 3599:
        return False
    if frequency == 0:
        return True
    return 3400 <= frequency <= 4200 or 10700 <= frequency <= 12750


def _be_bytes(values):
    data = ''.join(chr(value & 0xFF) for value in values)
    if not isinstance(data, bytes):
        data = data.encode('latin-1')
    return data


def _namespace_biss_id(sid, service_ref):
    """Compute OSCam's first-priority namespace hash from a service reference.

    This mirrors module-emulator-biss.c: hash over [sid][namespace], or
    [sid][tsid][onid][namespace] when the frequency is stripped. It is only
    used after the log proves OSCam requested an ECM for the same SID/PMT.
    """
    try:
        import zlib
        parts = (service_ref or '').split(':')
        if len(parts) < 7:
            return None
        namespace = int(parts[6], 16)
        tsid = int(parts[4], 16)
        onid = int(parts[5], 16)
    except (ValueError, TypeError):
        return None
    namespace = (namespace & 0x0FFFFFFF) | 0xA0000000
    if not _is_valid_namespace(namespace):
        return None
    namespace = _unify_orbitals(namespace)
    if namespace & 0xFFFF:
        values = [sid >> 8, sid & 0xFF,
                  namespace >> 24, (namespace >> 16) & 0xFF,
                  (namespace >> 8) & 0xFF, namespace & 0xFF]
    else:
        values = [sid >> 8, sid & 0xFF, tsid >> 8, tsid & 0xFF,
                  onid >> 8, onid & 0xFF,
                  namespace >> 24, (namespace >> 16) & 0xFF,
                  (namespace >> 8) & 0xFF, namespace & 0xFF]
    return '{:08X}'.format(zlib.crc32(_be_bytes(values), 0x2600) & 0xFFFFFFFF)


def _recent_ecm_request(lines, sid, pmt_pid):
    """True if OSCam built a BISS ECM for exactly this SID and PMT recently."""
    pending = {}
    for line in lines:
        prefix = re.match(r'^(.{19})\s+([0-9A-F]{8})\s+[cr]\s+', line, re.IGNORECASE)
        if not prefix:
            continue
        try:
            stamp = _timemod.mktime(_timemod.strptime(prefix.group(1), '%Y/%m/%d %H:%M:%S'))
        except (ValueError, OverflowError):
            continue
        thread = prefix.group(2).upper()
        if 'trying to descramble' in line:
            meta = re.search(r'CAID\s+2600\b.*?PMTPID\s+([0-9A-F]{4})\b', line, re.IGNORECASE)
            if meta:
                pending[thread] = (stamp, int(meta.group(1), 16))
        elif '(ecm)' in line.lower():
            match = re.search(r'\(P:\s*2600:[0-9A-F]{6}:([0-9A-F]{4}):', line, re.IGNORECASE)
            if match and thread in pending:
                start, pmt = pending.pop(thread)
                if int(match.group(1), 16) == sid and pmt == pmt_pid and 0 <= stamp - start <= 5:
                    return True
    return False


def _accepted_oscam_key_ids(lines, sid, pmt_pid, cw_hex):
    """Recognize successful, non-interleaved SID/PMT/CW-matched ECM blocks."""
    if not cw_hex or not re.match(r'\A[0-9A-F]{16}\Z', cw_hex, re.IGNORECASE):
        return set()
    wanted_cw = cw_hex.upper() * 2
    accepted = set()
    starts = []
    found = []
    for line in lines:
        prefix = re.match(r'^(.{19})\s+([0-9A-F]{8})\s+([cr])\s+', line, re.IGNORECASE)
        if not prefix:
            continue
        try:
            stamp = _timemod.mktime(_timemod.strptime(prefix.group(1), '%Y/%m/%d %H:%M:%S'))
        except (ValueError, OverflowError):
            continue
        if 'trying to descramble' in line:
            metadata = re.search(r'CAID\s+2600\b.*?ECMPID\s+([0-9A-F]{4})\b.*?PMTPID\s+([0-9A-F]{4})\b', line, re.IGNORECASE)
            starts.append((prefix.group(2).upper(), stamp, metadata.groups() if metadata else None))
        elif '(emu)' in line.lower():
            match = re.search(r'Key found:\s+F\s+([0-9A-F]{8})\s+[0-9A-F]{8}\b', line, re.IGNORECASE)
            if match and starts:
                found.append((match.group(1).upper(), stamp))
        elif '(ecm)' in line.lower():
            match = re.search(r'\(P:\s*2600:[0-9A-F]{6}:([0-9A-F]{4}):([0-9A-F]{4}):', line, re.IGNORECASE)
            cw = re.search(r'#CW=([0-9A-F]{32})\b', line, re.IGNORECASE)
            success = re.search(r'\):\s*found\s+\(', line, re.IGNORECASE)
            if len(starts) == 1 and len(found) == 1 and match and cw and success:
                thread, start_stamp, metadata = starts[0]
                key_id, found_stamp = found[0]
                if (metadata and prefix.group(2).upper() == thread
                        and int(match.group(1), 16) == sid
                        and int(metadata[1], 16) == pmt_pid
                        and match.group(2).upper() == metadata[0].upper()
                        and cw.group(1).upper() == wanted_cw
                        and 0 <= found_stamp - start_stamp <= stamp - start_stamp <= 5):
                    accepted.add(key_id)
            starts = []
            found = []
    return accepted


def get_oscam_key_id(sid, cw_hex=None, pmt_pid=None, service_ref=None, wait=0):
    """Return a BISS identifier proven to belong to this SID and PMT.

    Priority: explicit universal-hash example, actual successful Key found
    transaction, then OSCam's own namespace-hash algorithm computed from the
    current service reference after a recent ECM request for the same SID/PMT.
    Missing, conflicting, stale or interleaved evidence never permits guessing.
    """
    try:
        sid_int = int(sid)
        pmt_int = int(pmt_pid.strip(), 16) if hasattr(pmt_pid, 'strip') else int(pmt_pid)
        if not (0 <= sid_int <= 0xFFFF and 0 < pmt_int < 0x1FFF):
            return None
    except Exception:
        return None
    pattern = re.compile(
        r'\(emu\)\s+Example key based on universal hash:\s+F\s+'
        r'([0-9A-F]{8})\s+[0-9A-F]{8}\s+X{16}\s*;\s*'
        r'av:\d+\s+pmt:([0-9A-F]{4})\s+sid:([0-9A-F]{4})\b',
        re.IGNORECASE)
    identifiers = set()
    accepted = set()
    events = []
    paths = (OSCAM_LOG_FILE + '-prev', OSCAM_LOG_FILE)
    def snapshot():
        result = []
        for path in paths:
            try:
                stat = os.stat(path)
                result.append((stat.st_ino, stat.st_size, stat.st_mtime))
            except (IOError, OSError):
                result.append(None)
        return result

    # The identifier may appear a moment after the VPS returns the CW.
    # Wait briefly (automatic flow) but never guess when evidence is absent.
    deadline = _timemod.time() + max(0.0, float(wait or 0))
    stable = False
    while True:
        identifiers = set()
        accepted = set()
        events = []
        stable = False
        now = _timemod.time()
        for attempt in range(2):
            before = snapshot()
            for path in paths:
                try:
                    with open(path, 'r') as f:
                        for line in f:
                            match = pattern.search(line)
                            if not match and not any(event in line.lower() for event in ('trying to descramble', '(ecm)', 'key found:')):
                                continue
                            try:
                                stamp = _timemod.mktime(_timemod.strptime(line[:19], '%Y/%m/%d %H:%M:%S'))
                            except (ValueError, OverflowError):
                                continue
                            if -5 <= now - stamp <= 120:
                                events.append(line)
                                if match and int(match.group(2), 16) == pmt_int and int(match.group(3), 16) == sid_int:
                                    identifiers.add(match.group(1).upper())
                except (IOError, OSError):
                    continue
            accepted.update(_accepted_oscam_key_ids(events, sid_int, pmt_int, cw_hex))
            if before == snapshot():
                stable = True
                break
        if stable and (identifiers or accepted or
                       (service_ref and _recent_ecm_request(events, sid_int, pmt_int))):
            break
        if _timemod.time() >= deadline:
            break
        if _sleep:
            _sleep(0.5)
    if not stable:
        return None
    if len(identifiers) == 1:
        return identifiers.pop()
    if not identifiers and len(accepted) == 1:
        return accepted.pop()
    if not identifiers and not accepted and service_ref and _recent_ecm_request(events, sid_int, pmt_int):
        computed = _namespace_biss_id(sid_int, service_ref)
        if computed:
            log_debug("get_oscam_key_id: computed namespace id {} for SID {:04X}".format(computed, sid_int))
            return computed
    return None


def write_softcam_key(sid, pmt_pid, cw_hex, channel_name="AutoBiss",
                      ecm_pid=None, provider="", applied_key=None,
                      service_ref="", identifier_wait=0):
    """
    Write/update a BISS key in SoftCam.Key.

    The key id must be explicitly correlated with this SID and PMT in OSCam's
    universal-hash example or a successful CW-matched ECM. No ID is guessed.
    Optional applied_key receives the exact identifier/CW after a true result.
    Format:
        F <KEY_ID> 00000000 <CW> ;<Channel> (<provider>) [AutoBiss]
    """
    if applied_key is not None:
        applied_key.clear()
    if not cw_hex or not re.match(r'\A[0-9A-Fa-f]{16}\Z', cw_hex):
        log_debug("write_softcam_key: invalid CW")
        return False

    cw_str = cw_hex.upper()

    # Ask OSCam for the key id it derived from the current ECM.
    key_id = None
    try:
        key_id = get_oscam_key_id(sid, cw_str, pmt_pid=pmt_pid,
                                  service_ref=service_ref,
                                  wait=identifier_wait)
    except Exception as e:
        log_debug("write_softcam_key: get_oscam_key_id error: {}".format(e))

    try:
        sid_int = int(sid)
    except Exception:
        log_debug("write_softcam_key: invalid SID")
        return False

    sid_str = "{:04X}".format(sid_int & 0xFFFF)
    if key_id:
        key_id = key_id.upper()
        log_debug("write_softcam_key: OSCam ECM key id {}".format(key_id))
    else:
        log_debug("write_softcam_key: no unambiguous OSCam identifier for SID {}; file unchanged".format(sid_str))
        return False

    comment = channel_name or "AutoBiss"
    provider = (provider or "").strip()
    if provider:
        comment = "{} ({})".format(comment, provider)
    comment = ' '.join(comment.splitlines())
    comment = "{} [AutoBiss]".format(comment)
    entry = "F {} 00000000 {} ;{}\n".format(key_id, cw_str, comment)

    softcam_path = get_softcam_path()

    lines = []
    if os.path.isfile(softcam_path):
        try:
            with open(softcam_path, 'r') as f:
                lines = f.readlines()
        except Exception as e:
            log_debug("Failed to read SoftCam.Key: {}".format(e))
            return False

    # Exact entry already present: nothing to do.
    entry_norm = entry.strip().upper()
    for line in lines:
        if line.strip().upper() == entry_norm:
            if applied_key is not None:
                applied_key.update(key_id=key_id, cw_hex=cw_str)
            return True

    # Replace only AutoBiss-owned entries for this service: the new key id
    # and old SID+PMT fallback lines.  Manual/custom lines are never deleted.
    auto_pattern = re.compile(
        r'^F\s+(?:' + re.escape(key_id) + r'|' + re.escape(sid_str) +
        r'[0-9A-Fa-f]{4})\s+.*\[AutoBiss\]',
        re.IGNORECASE)

    new_lines = []
    written = False
    for line in lines:
        if auto_pattern.match(line):
            if not written:
                new_lines.append(entry)
                written = True
            continue
        new_lines.append(line)

    if not written:
        if new_lines and not new_lines[-1].endswith('\n'):
            new_lines[-1] += '\n'
        new_lines.append(entry)

    try:
        with open(softcam_path, 'w') as f:
            f.writelines(new_lines)
        log_debug("SoftCam.Key {} updated: {} -> {}".format(
            softcam_path, key_id, _mask_cw(cw_str)))
        if applied_key is not None:
            applied_key.update(key_id=key_id, cw_hex=cw_str)
        return True
    except Exception as e:
        log_debug("Failed to write SoftCam.Key: {}".format(e))
        return False

# ------------------------------------------------------------------------------
# ECM Info Writer  (/tmp/ecm.info — read by some softcam-aware apps)
# ------------------------------------------------------------------------------
def write_ecm_info(sid, ecm_pid, cw_hex, channel_name="AutoBiss"):
    """
    Write /tmp/ecm.info in the format expected by softcam monitors.
    cw_hex must be 16 hex chars (8 bytes). Both cw0 and cw1 are set
    to the same value (BISS uses a single symmetric CW).
    """
    if not cw_hex or len(cw_hex) != 16:
        log_debug("write_ecm_info: invalid CW length")
        return False
    try:
        # Format CW as space-separated byte pairs: "1A 2B 3C 81 4D 5E 6F 1A "
        cw = cw_hex.upper()
        cw_fmt = ' '.join(cw[i:i+2] for i in range(0, 16, 2)) + ' '

        # Normalise ECM PID to hex int then format
        try:
            pid_int = int(str(ecm_pid).replace('0x','').replace('0X',''), 16)
        except Exception:
            pid_int = 0x1FFF
        pid_str = '0x{:04X}'.format(pid_int)

        content = (
            "system: Biss\n"
            "caid: 0x2600\n"
            "provider: {provider}\n"
            "provid: 0x000000\n"
            "pid: {pid}\n"
            "cw0: {cw}\n"
            "cw1: {cw}\n"
            "using: emu\n"
            "address: local:0\n"
            "hops: 0\n"
            "ecm time: 2\n"
        ).format(provider=channel_name, pid=pid_str, cw=cw_fmt)

        with open('/tmp/ecm.info', 'w') as f:
            f.write(content)
        log_debug("write_ecm_info: written for SID 0x{:04X}".format(sid))
        return True
    except Exception as e:
        log_debug("write_ecm_info error: {}".format(e))
        return False

# ------------------------------------------------------------------------------
# Recording Sidecar Cleanup
# ------------------------------------------------------------------------------
def cleanup_recording_sidecars(ts_path):
    """
    Remove all Enigma2 sidecar files left next to a TS recording:
    .eit, .ts.cuts, .ts.meta, .ts.sc, .ts.ap, and AutoBiss .txt logs.
    """
    if not ts_path:
        return
    movie_dir = os.path.dirname(ts_path)
    base = ts_path  # e.g. /media/hdd/movie/20260531 1325 - Chan - AutoBiss Chan.ts

    # Strip .ts suffix to get the stem
    stem = base[:-3] if base.endswith('.ts') else base

    # Sidecar extensions attached to the stem
    for ext in ('.eit', '.ts.cuts', '.ts.meta', '.ts.sc', '.ts.ap'):
        path = stem + ext if ext.startswith('.ts.') else stem + ext
        # For extensions like .ts.cuts, stem already has no .ts so we need:
        if ext.startswith('.ts.'):
            path = stem + ext          # stem + .ts.cuts → correct
        else:
            path = stem + ext          # stem + .eit
        try:
            if os.path.isfile(path):
                os.remove(path)
                log_debug("Removed sidecar: {}".format(path))
        except Exception as e:
            log_debug("Sidecar remove failed {}: {}".format(path, e))

    # AutoBiss .txt info files for THIS recording only (never touch others)
    try:
        wanted = set()
        for ext in ('.txt', '.log', '.info'):
            wanted.add(os.path.basename(stem) + ext)
        for fname in os.listdir(movie_dir):
            if fname in wanted:
                fpath = os.path.join(movie_dir, fname)
                try:
                    os.remove(fpath)
                    log_debug("Removed AutoBiss txt: {}".format(fpath))
                except Exception as e:
                    log_debug("AutoBiss txt remove failed {}: {}".format(fpath, e))
    except Exception as e:
        log_debug("Sidecar dir scan failed: {}".format(e))

# ------------------------------------------------------------------------------
# Softcam Reloader
# ------------------------------------------------------------------------------
def _find_softcam_pids():
    """Return pids of running oscam/ncam processes using /proc/<pid>/exe.

    Matching the executable (not the full command line) avoids false hits on
    shells, pgrep/pkill or scripts that merely contain the word 'oscam'.
    """
    pids = []
    try:
        my_pid = os.getpid()
    except Exception:
        my_pid = 0
    try:
        entries = os.listdir('/proc')
    except Exception:
        return pids
    for entry in entries:
        if not entry.isdigit():
            continue
        pid = int(entry)
        if pid == my_pid:
            continue
        try:
            exe = os.readlink('/proc/{}/exe'.format(entry))
        except Exception:
            continue
        base = os.path.basename(exe).lower()
        if base.startswith('oscam') or base.startswith('ncam'):
            pids.append(pid)
    return pids


def _read_cam_sections(path):
    """Read repeated OSCam INI sections without logging their secret values."""
    sections = []
    current = None
    with open(path, 'r') as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith(('#', ';')):
                continue
            if line.startswith('[') and line.endswith(']'):
                current = {'section': line[1:-1].lower()}
                sections.append(current)
            elif current is not None and '=' in line:
                key, value = line.split('=', 1)
                current[key.strip().lower()] = value.strip()
    return sections


def _loaded_biss_entitlements(body):
    """Extract ID/date/CW tuples from individual WebIF entitlement rows."""
    loaded = set()
    for row in re.findall(r'<tr\b[^>]*>(.*?)</tr>', body, re.IGNORECASE | re.DOTALL):
        text = re.sub(r'<[^>]*>', ' ', row)
        match = re.search(r'\bkey\s+2600\s+([0-9A-F]{1,8})\s+'
                          r'([0-9A-F]{8})\s+([0-9A-F]{16})\b', text, re.IGNORECASE)
        if match:
            loaded.add((match.group(1).upper().zfill(8), match.group(2).upper(), match.group(3).upper()))
    return loaded


def reload_softcam(key_id=None, cw_hex=None):
    """Refresh the active emulator and verify actual BISS entitlements.

    SIGHUP only rereads accounts on some builds: delivery is not key loading.
    Fail closed if WebIF is unavailable; never restart OSCam or alter readers.
    This confirms keys in memory, not successful payload decryption/playback.
    """
    try:
        try:
            import urllib2
            from urllib import quote
        except ImportError:
            import urllib.request as urllib2
            from urllib.parse import quote

        instance = _detect_emu_instance()
        if not instance:
            log_debug('Softcam refresh: active configuration directory unavailable')
            return False
        config_dir = instance['config_dir']
        path = os.path.join(config_dir, instance['name'] + '.conf')
        webif = [s for s in _read_cam_sections(path) if s['section'] == 'webif']
        if len(webif) != 1:
            log_debug('Softcam refresh: WebIF configuration unavailable or ambiguous')
            return False
        config = webif[0]
        port = int(config.get('httpport', '0'))
        if not 0 < port <= 65535:
            return False

        path = os.path.join(config_dir, instance['name'] + '.server')
        readers = [s for s in _read_cam_sections(path)
                   if s['section'] == 'reader' and s.get('protocol', '').lower() == 'emu'
                   and s.get('enable', '1') != '0' and s.get('label')]
        if len(readers) != 1:
            log_debug('Softcam refresh: active emulator reader unavailable or ambiguous')
            return False

        expected = set()
        pattern = re.compile(r'^F\s+([0-9A-F]{8})\s+([0-9A-F]{8})\s+([0-9A-F]{16})(?:\s|;|$)', re.IGNORECASE)
        with open(get_softcam_path(), 'r') as f:
            for line in f:
                match = pattern.match(line.strip())
                if match:
                    expected.add(tuple(value.upper() for value in match.groups()))
        if key_id is not None or cw_hex is not None:
            target = ((key_id or '').upper(), '00000000', (cw_hex or '').upper())
            if target not in expected:
                log_debug('Softcam refresh: applied key is absent from SoftCam.Key')
                return False
            expected = set([target])
        if not expected:
            log_debug('Softcam refresh: no BISS keys to verify')
            return False

        hosts = ['127.0.0.1']
        try:
            import socket
            probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            try:
                probe.connect(('8.8.8.8', 80))
                lan_ip = probe.getsockname()[0]
            finally:
                probe.close()
            if lan_ip and not lan_ip.startswith('127.') and lan_ip not in hosts:
                hosts.append(lan_ip)
        except Exception:
            pass

        label = quote(readers[0]['label'], safe='')
        refreshed = False
        last_error = None
        base = None
        opener = None
        for host in hosts:
            base = 'http://{}:{}'.format(host, port)
            passwords = urllib2.HTTPPasswordMgrWithDefaultRealm()
            passwords.add_password(None, base, config.get('httpuser', ''), config.get('httppwd', ''))
            opener = urllib2.build_opener(urllib2.ProxyHandler({}), urllib2.HTTPDigestAuthHandler(passwords))
            try:
                response = opener.open(base + '/readers.html?action=reread&label=' + label, timeout=3)
                try:
                    response.read(2 * 1024 * 1024)
                finally:
                    response.close()
                refreshed = True
                break
            except Exception as e:
                last_error = type(e).__name__
                if hasattr(e, 'close'):
                    e.close()
                continue
        if not refreshed:
            log_debug('Softcam refresh: WebIF unreachable ({})'.format(last_error or 'unknown'))
            return False
        for attempt in range(3):
            response = opener.open(base + '/entitlements.html?label=' + label + '&hideexpired=0', timeout=3)
            try:
                body = response.read(2 * 1024 * 1024).decode('utf-8', 'replace')
            finally:
                response.close()
            if expected.issubset(_loaded_biss_entitlements(body)):
                log_debug('Softcam refresh: {} BISS key(s) verified in emulator memory; playback unverified'.format(len(expected)))
                return True
            if attempt < 2 and _sleep:
                _sleep(0.25)
        log_debug('Softcam refresh: loaded entitlements do not match SoftCam.Key; playback unverified')
    except Exception as e:
        # Exception messages/URLs/HTTP bodies may contain credentials or keys.
        if hasattr(e, 'close'):
            e.close()
        log_debug('Softcam refresh failed ({})'.format(type(e).__name__))
    return False

# ------------------------------------------------------------------------------
# Key Formatter
# ------------------------------------------------------------------------------
def format_cw_for_display(cw_hex):
    if not cw_hex or len(cw_hex) != 16:
        return "Unknown"
    return "{} {}".format(cw_hex[:8], cw_hex[8:])


def format_key_found_text(cw_hex):
    """OSD text shown when a key was written and verified in emulator memory."""
    cw = (cw_hex or '').strip().upper()
    if not re.match(r'\A[0-9A-F]{16}\Z', cw):
        return "Key Found"
    return "Key Found : {}".format(cw)


def format_feed_satellite(name, width=11):
    """Compact, unambiguous satellite label for the Live Feeds list.

    Stored names look like ``Eutelsat Hot Bird 13 (13.0E)``.  The old screen
    cut them at 11 characters and put the polarization letter immediately
    after, producing labels such as ``Eutelsat HoV``.  Drop the redundant
    brand where possible, normalize dashes, and fall back to the orbital
    position when the name still does not fit.
    """
    text = (name or '').strip()
    if not text:
        return '?'
    position = ''
    match = re.search(r'\(([^()]*)\)\s*$', text)
    if match:
        position = match.group(1).strip()
        text = text[:match.start()].strip()
    low = text.lower()
    if low.startswith('eutelsat '):
        text = text[9:].strip()
    elif low.startswith('hellas sat '):
        text = 'Hellas ' + text[11:].strip()
    text = re.sub(r'\s*-\s*', '-', text)
    text = re.sub(r'\s+', ' ', text).strip()
    if len(text) <= width:
        return text or position or '?'
    if position:
        return position
    cut = text[:width + 1].rsplit(' ', 1)[0]
    return cut if len(cut) >= 5 else text[:width]


def feed_orbital_position(name):
    """Return Enigma2 orbital position (tenths of degree, west=3600-x)."""
    match = re.search(r'\(([^()]*)\)\s*$', name or '')
    if not match:
        return None
    inner = match.group(1).replace(' ', '').upper()
    if len(inner) < 2 or inner[-1] not in ('E', 'W'):
        return None
    try:
        value = float(inner[:-1])
    except ValueError:
        return None
    if value < 0 or value > 180:
        return None
    tenths = int(round(value * 10))
    return 3600 - tenths if inner[-1] == 'W' else tenths


def parse_feed_scan(feed):
    """Derive scan parameters from a Live Feeds row, or None if unusable.

    Returns frequency in kHz and symbol rate in baud (the units expected by
    eDVBFrontendParametersSatellite), plus the orbital position and the
    DVB system/modulation implied by the feed format.
    """
    feed = feed or {}
    try:
        raw_freq = str(feed.get('frequency') or '').strip().replace(' ', '')
        frequency = float(raw_freq)
    except (TypeError, ValueError):
        return None
    if not 1000 <= frequency <= 30000:
        return None
    polarization = str(feed.get('polarization') or 'H').strip().upper()[:1]
    if polarization not in ('H', 'V'):
        polarization = 'H'
    raw_sr = str(feed.get('symbolrate') or '').strip().replace(' ', '')
    symbol_rate = None
    if raw_sr:
        try:
            if '.' in raw_sr[1:] or ',' in raw_sr[1:]:
                symbol_rate = int(round(float(raw_sr.replace(',', '.')) * 1000))
            else:
                digits = ''.join(ch for ch in raw_sr if ch.isdigit())
                symbol_rate = int(digits) if digits else None
        except (TypeError, ValueError):
            symbol_rate = None
    if not symbol_rate or symbol_rate < 1000:
        symbol_rate = 27500
    orbital = feed_orbital_position(feed.get('satellite'))
    if orbital is None:
        return None
    fmt = str(feed.get('format') or '').upper()
    if 'DVB-S2' in fmt:
        system = 'DVB-S2'
    elif 'DVB-S' in fmt:
        system = 'DVB-S'
    else:
        system = 'DVB-S2'
    if '32APSK' in fmt:
        modulation = '32APSK'
    elif '16APSK' in fmt:
        modulation = '16APSK'
    elif '8PSK' in fmt:
        modulation = '8PSK'
    else:
        modulation = 'QPSK'
    return {
        'frequency_khz': int(round(frequency * 1000)),
        'polarization': polarization,
        'symbol_rate': symbol_rate * 1000,
        'orbital': orbital,
        'system': system,
        'modulation': modulation,
    }


def choose_feed_tuner(slots, orbital):
    """Pick the first DVB-S tuner slot whose satellite list contains orbital."""
    for slot, satellites in slots or []:
        try:
            if orbital in satellites:
                return slot
        except TypeError:
            continue
    return None
